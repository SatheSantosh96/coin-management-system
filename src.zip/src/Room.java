
public class Room {
	int roomNo;
	String roomType;
	String name;
	int deviceCount;
	Device[] devices=new Device[10];
	
	public Room(int roomNo, String roomType, String name) {
		super();
		this.roomNo = roomNo;
		this.roomType = roomType;
		this.name = name;
		this.deviceCount=0;
	}
	public int getRoomNo() {
		return roomNo;
	}
	public void setRoomNo(int roomNo) {
		this.roomNo = roomNo;
	}
	public String getRoomType() {
		return roomType;
	}
	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}
	/**
	 * @return the name
	 */
	public final String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public final void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the deviceCount
	 */
	public final int getDeviceCount() {
		return deviceCount;
	}
	/**
	 * @param deviceCount the deviceCount to set
	 */
	public final void setDeviceCount(int deviceCount) {
		this.deviceCount = deviceCount;
	}
	
	
	
	
	
}
